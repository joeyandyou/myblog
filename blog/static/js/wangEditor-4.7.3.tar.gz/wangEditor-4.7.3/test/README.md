# 单元测试

- jest 模拟 DOM 环境
- 初始化编辑器
- selection 和 command
- 各个配置项和监听事件
- API ，如获取内容、追加内容
- text 功能
- 各个菜单功能
- utils

`npm run test-c` 可看到测试覆盖率，可对覆盖率差的文件，继续测试
