module.exports = {
    extends: ['cz'],
    rules: {
        'type-empty': [2, 'never'],
    },
}
