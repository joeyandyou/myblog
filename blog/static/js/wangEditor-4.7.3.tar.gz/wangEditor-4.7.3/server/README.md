# 服务端

`npm start` 时会启动 server ，依赖于 koa2-static 来启动 examples 页面的静态服务。
